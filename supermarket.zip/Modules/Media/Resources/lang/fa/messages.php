<?php

return [
    'internal_error'=>"خطا در انجام عملیات",
    'media_was_delete'=>"مدیا حذف شد.",
    'media_not_found'=>"مدیا پیدا نشد.",
];
