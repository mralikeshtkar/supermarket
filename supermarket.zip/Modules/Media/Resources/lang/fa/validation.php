<?php

use Modules\Media\Rules\MediaModelRule;

return [
    MediaModelRule::class => "اطلاعات معتبر نمیباشد."
];
