<?php

use Modules\Media\Rules\MediaModelRule;

return [
    MediaModelRule::class => "Model is incorrect."
];
