<?php

return [
    'internal_error'=>"Internal Error",
    'media_was_delete'=>"Media was delete.",
    'media_not_found'=>"Media not found.",
];
