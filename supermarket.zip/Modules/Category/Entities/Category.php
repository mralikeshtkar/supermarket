<?php

namespace Modules\Category\Entities;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Relations\MorphToMany;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Modules\Category\Database\factories\CategoryFactory;
use Modules\Category\Enums\CategoryStatus;
use Modules\Core\Responses\Api\ApiResponse;
use Modules\Feature\Traits\HasFeature;
use Modules\Media\Entities\Media;
use Modules\Media\Traits\HasMedia;
use Modules\Product\Entities\Product;
use Symfony\Component\HttpFoundation\Response;

class Category extends Model
{
    use HasFactory, HasFeature, HasMedia;

    #region Constants

    /**
     * Fill ables field.
     *
     * @var string[]
     */
    protected $fillable = [
        'user_id',
        'parent_id',
        'name',
        'slug',
        'status',
    ];

    protected $with = [
        'parent',
    ];

    #endregion

    #region Methods

    /**
     * Check is exists categories with specified ids where status is accepted and categories count with these rules equals to ids count.
     *
     * @param array $ids
     * @return bool
     */
    public function whereExistsAcceptedWithIds(array $ids): bool
    {
        return self::query()->whereIn('id', $ids)->accepted()->count() == count($ids);
    }

    /**
     * Init category model factory
     *
     * @return CategoryFactory
     */
    protected static function newFactory(): CategoryFactory
    {
        return CategoryFactory::new();
    }

    /**
     * Initialize model.
     *
     * @return Category
     */
    public static function init(): Category
    {
        return new self();
    }

    public function allCategories()
    {
        return self::query()->get();
    }

    public function onlyAccepted(Request $request)
    {
        return self::query()
            ->when($request->filled('search'), function (Builder $builder) use ($request) {
                $builder->where('name', 'LIKE', '%' . $request->search . '%')
                    ->orWhere('slug', 'LIKE', '%' . $request->search . '%');
            })->accepted()
            ->get();
    }

    public function getAdminIndexPaginate(Request $request, $category = null)
    {
        return self::query()
            ->with('image')
            ->latest()
            ->when($request->filled('name'), function (Builder $builder) use ($request) {
                $builder->where('name', 'LIKE', '%' . $request->name . '%')
                    ->orWhere('slug', 'LIKE', '%' . $request->name . '%');
            })->when($category, function (Builder $builder) use ($category) {
                $builder->where('parent_id', $category);
            }, function (Builder $builder) use ($category) {
                $builder->whereNull('parent_id');
            })->paginate(2)
            ->appends($request->only('name'));
    }

    /**
     * Find or fail a category with slug.
     *
     * @param $category
     * @return Builder|Model
     */
    public function findOrFailById($category): Model|Builder
    {
        return self::query()->findOrFail($category);
    }

    /**
     * Store a category with request data.
     *
     * @param Request $request
     * @return Model|Builder
     */
    public function store(Request $request): Model|Builder
    {
        $category = self::query()->create([
            'user_id' => $request->user()->id,
            'name' => $request->name,
            'slug' => Str::slug($request->slug),
            'parent_id' => $request->parent_id,
        ]);
        $category->when($request->hasFile('image'), function () use ($request, $category) {
            $category->setCollection(config('category.collection_gallery'))
                ->setDirectory('categories')
                ->addMedia($request->image);
        });
        return $category->load('images');
    }

    /**
     * Update a category with request data.
     *
     * @param $category
     * @param $request
     * @return mixed
     */
    public function updateCategory($category, $request): mixed
    {
        $category->update([
            'name' => $request->name,
            'slug' => Str::slug($request->slug),
            'parent_id' => $request->parent_id,
        ]);
        $category->when($request->hasFile('image'), function () use ($request, $category) {
            $category->setCollection(config('category.collection_gallery'))
                ->setDirectory('categories')
                ->addMedia($request->image);
        });
        return $category->refresh()->load('images');
    }

    /**
     * Change status category with specified status.
     *
     * @param $category
     * @param $status
     * @return mixed
     */
    public function changeStatus($category, $status): mixed
    {
        return $category->update([
            'status' => $status,
        ]);
    }

    /**
     * Destroy a category.
     *
     * @param $category
     * @return mixed
     */
    public function destroyCategory($category): mixed
    {
        return $category->delete();
    }

    /**
     * Get translated status.
     *
     * @return mixed
     */
    public function getStatus(): mixed
    {
        return CategoryStatus::fromValue($this->getAttribute('status'))->description;
    }

    #endregion

    #region Scopes

    /**
     * Add scope where status is accepted condition.
     *
     * @param Builder $builder
     * @return void
     */
    public function scopeAccepted(Builder $builder)
    {
        $builder->where('status', CategoryStatus::Accepted);
    }

    #endregion

    #region Relationships

    /**
     * @return MorphToMany
     */
    public function products(): MorphToMany
    {
        return $this->morphedByMany(Product::class, 'categorizables');
    }

    /**
     * @return mixed
     */
    public function images(): mixed
    {
        return $this->media()
            ->select('id', 'model_id', 'model_type', 'disk', 'files')
            ->where('collection', config('category.collection_gallery'))
            ->orderByAscPriority()
            ->oldest();
    }

    /**
     * @return mixed
     */
    public function image(): mixed
    {
        return $this->morphOne(Media::class, 'model')
            ->select('id', 'model_id', 'model_type', 'disk', 'files')
            ->where('collection', config('category.collection_gallery'))
            ->orderByAscPriority()
            ->oldest();
    }

    /**
     * @return BelongsTo
     */
    public function parent(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'parent_id', 'id');
    }

    #endregion
}
