<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'category_not_found'=>"category not found",
    'category_was_created'=>"Category was created",
    'category_was_updated'=>"Category was updated",
    'category_was_deleted'=>"Category was deleted",
];
