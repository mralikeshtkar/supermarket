<?php

return [
    'received_information_successfully' => "دریافت اطلاعات با موفقیت انجام شد",
    'internal_error'=>"خطا در انجام عملیات",
    'category_not_found'=>"دسته مورد نظر پیدا نشد",
    'category_was_created'=>"دسته با موفقیت ایجاد شد",
    'category_was_updated'=>"دسته با موفقیت بروزرسانی شد",
    'category_was_deleted'=>"دسته با موفقیت حذف شد",
];
