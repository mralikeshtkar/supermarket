<?php

return [
    'name' => 'Category',
    'collection_gallery' => "gallery",
];
