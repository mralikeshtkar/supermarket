<?php

namespace Modules\Category\Http\Controllers\V1\Api;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Modules\Category\Entities\Category;
use Modules\Category\Enums\CategoryStatus;
use Modules\Core\Responses\Api\ApiResponse;
use Modules\Permission\Entities\Permission;
use OpenApi\Annotations as OA;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class ApiCategoryController extends Controller
{
    /**
     * Get all categories as a json.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function categories(Request $request)
    {
        return ApiResponse::message(trans('category::messages.received_information_successfully'))
            ->addData('categories', Category::all())
            ->send();
    }

    /**
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function products(Request $request, $slug)
    {
        try {
            $category = Category::init()->findOrFailWithSlug($slug);
            return ApiResponse::message(trans('category::messages.received_information_successfully'))
                ->addData('category',$category)
                ->addData('products',$category->products()->paginate())
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendMessage(trans('category::messages.category_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('category::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * Change status a category to accepted.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function accept(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('action', Permission::class));
        return $this->_changeStatus($slug, CategoryStatus::Accepted);
    }

    /**
     * Change status a category to rejected.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function reject(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('action', Permission::class));
        return $this->_changeStatus($slug, CategoryStatus::Rejected);
    }

    /**
     * Show category features.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function features(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('manage', Permission::class));
        try {
            $category = Category::init()->findOrFailWithSlug($slug);
            $category->load('features');
            return ApiResponse::message(trans('category::messages.received_information_successfully'))
                ->addData('category', $category)
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendMessage(trans('category::messages.category_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('category::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * Manage change status a category.
     *
     * @param $slug
     * @param $status
     * @return JsonResponse
     */
    private function _changeStatus($slug, $status): JsonResponse
    {
        try {
            $category = Category::init()->findOrFailWithSlug($slug);
            Category::init()->changeStatus($category, $status);
            return ApiResponse::message(trans('category::messages.category_was_updated'))
                ->addData('category', [
                    'name' => $category->name,
                    'slug' => $category->slug,
                    'status' => $category->getStatus(),
                ])
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendMessage(trans('category::messages.category_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('category::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }
}
