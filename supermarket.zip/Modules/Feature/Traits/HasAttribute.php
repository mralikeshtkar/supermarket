<?php

namespace Modules\Feature\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Concerns\HasRelationships;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Http\Request;
use Modules\Comment\Traits\HasComment;
use Modules\Feature\Entities\Attribute;
use Modules\Feature\Entities\Feature;

trait HasAttribute
{
    use HasRelationships;

    /**
     * @return MorphMany
     */
    public function attributes(): MorphMany
    {
        return $this->morphMany(Attribute::class, 'attributable');
    }

    /**
     * Initialize class.
     *
     * @return $this
     */
    public static function init(): static
    {
        return new self();
    }

    /**
     * @param $feature
     * @param Request $request
     * @return Model
     */
    public function storeAttribute($feature, Request $request): Model
    {
        return $this->attributes()
            ->create([
                'user_id' => optional($request->user())->id,
                'feature_id' => $feature->id,
                'option_id'=>$request->option_id,
                'value'=>$request->attribute_value,
            ]);
    }
}
