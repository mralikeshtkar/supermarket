<?php

namespace Modules\Feature\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Modules\Feature\Database\factories\FeatureOptionFactory;

class FeatureOption extends Model
{
    use HasFactory;

    #region Constance

    protected $fillable = [
        'feature_id',
        'value',
    ];

    #endregion

    #region Methods

    /**
     * Init factory class.
     *
     * @return FeatureOptionFactory
     */
    protected static function newFactory(): FeatureOptionFactory
    {
        return FeatureOptionFactory::new();
    }

    #endregion

    #region Relationships

    public function feature(): BelongsTo
    {
        return $this->belongsTo(Feature::class, 'feature_id');
    }

    #endregion
}
