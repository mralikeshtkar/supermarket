<?php

namespace Modules\Feature\Entities;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\Request;
use Modules\Feature\Database\factories\FeatureFactory;
use Modules\Feature\Traits\HasFeature;
use Modules\Product\Entities\Product;

class Feature extends Model
{
    use HasFactory, HasFeature;

    #region Constance

    protected $fillable = [
        'user_id',
        'parent_id',
        'featureable_id',
        'featureable_type',
        'title',
        'has_option',
        'is_filter',
    ];

    #endregion

    #region Methods

    /**
     * Init factory class.
     *
     * @return FeatureFactory
     */
    protected static function newFactory(): FeatureFactory
    {
        return FeatureFactory::new();
    }

    /**
     * Update a feature.
     *
     * @param $feature
     * @param Request $request
     * @return mixed
     */
    public function updateFeature($feature, Request $request): mixed
    {
        $feature->update([
            'parent_id' => $feature->filled('parent_id') ? $request->parent_id : $feature->parent_id,
            'title' => $request->title,
            'has_option' => $feature->filled('has_option') ? boolval($request->is_filter) : $feature->has_option,
            'is_filter' => $feature->filled('is_filter') ? boolval($request->is_filter) : $feature->is_filter,
        ]);
        return $feature->refresh();
    }

    /**
     * Store an option with options relationship.
     *
     * @param $request
     * @return Model
     */
    public function storeOption($request): Model
    {
        return $this->options()
            ->create([
                'value' => $request->option_value,
            ]);
    }

    /**
     * Find a feature where need options.
     *
     * @param $id
     * @param string $column
     * @return Model|Builder
     */
    public function findHasOptionOrFail($id, string $column = 'id'): Model|Builder
    {
        return self::query()
            ->where($column, $id)
            ->firstOrFail();
    }

    /**
     * @param $feature
     * @param string $column
     * @return bool
     */
    public function checkHasOptionByColumn($feature, string $column = 'id'): bool
    {
        return self::query()
            ->hasOption()
            ->where($column, $feature)
            ->exists();
    }

    /**
     * @param $feature
     * @param string $column
     * @return bool
     */
    public function checkDoesntHasOptionByColumn($feature, string $column = 'id'): bool
    {
        return self::query()
            ->doesntHasOption()
            ->where($column, $feature)
            ->exists();
    }

    /**
     * @param $product
     * @return Collection|array
     */
    public function productFeatures($product): Collection|array
    {
        return self::query()
            ->withWhereHas('children', function ($builder) use ($product) {
                $builder->withWhereHas('attributes', function ($builder) use ($product) {
                    $builder->whereHasMorph('attributable', [Product::class], function ($builder, $attributable) use ($product) {
                        $builder->where('id', $product->id);
                    });
                });
            })->parent()
            ->get();
    }

    #endregion

    #region Relationships

    /**
     * @return HasMany
     */
    public function options(): HasMany
    {
        return $this->hasMany(FeatureOption::class, 'feature_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    /**
     * @return HasMany
     */
    public function attributes(): HasMany
    {
        return $this->hasMany(Attribute::class, 'feature_id');
    }

    #endregion

    #region Scopes

    public function scopeParent(Builder $builder)
    {
        $builder->whereNull('parent_id');
    }

    public function scopeHasOption(Builder $builder)
    {
        $builder->where('has_option', true);
    }

    public function scopeDoesntHasOption(Builder $builder)
    {
        $builder->where('has_option', false);
    }

    #endregion
}
