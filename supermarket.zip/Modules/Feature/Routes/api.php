<?php

use Illuminate\Http\Request;
use Illuminate\Routing\Router;
use Modules\Feature\Http\Controllers\V1\Api\ApiFeatureController as V1ApiFeatureController;
use Modules\Feature\Http\Controllers\V1\Api\ApiAttributeController as V1ApiAttributeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('v1')->group(function (Router $router) {
    $router->middleware('auth:sanctum')->group(function (Router $router) {
        $router->post('features', [V1ApiFeatureController::class, 'store'])
            ->name('feature.v1.api-feature.store.post.api');
        $router->match(['patch', 'put'], 'features/{feature}', [V1ApiFeatureController::class, 'update'])
            ->name('feature.v1.api-feature.update.put-patch.api');
        $router->get('features/{feature}/options', [V1ApiFeatureController::class, 'options'])
            ->name('feature.v1.api-feature.options.get.api');
        $router->post('features/{feature}/options', [V1ApiFeatureController::class, 'storeOptions'])
            ->name('feature.v1.api-feature.store-options.post.api');
        $router->get('features/{feature}', [V1ApiFeatureController::class, 'show'])
            ->name('feature.v1.api-feature.show.get.api');
        $router->post('features/{feature}/attributes', [V1ApiAttributeController::class, 'store'])
            ->name('feature.v1.api-attribute.store.post.api');
    });
});
