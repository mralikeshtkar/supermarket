<?php

return [
    'received_information_successfully' => "دریافت اطلاعات با موفقیت انجام شد",
    'internal_error'=>"خطا در انجام عملیات",
    'feature_was_created'=>"ویژگی با موفقیت ایجاد شد",
    'feature_option_was_created'=>"گزینه ویژگی با موفقیت ایجاد شد",
    'attribute_option_was_created'=>"صفت با موفقیت ایجاد شد",
    'feature_was_updated'=>"ویژگی با موفقیت بروزرسانی شد",
    'feature_not_found'=>"ویژگی پیدا نشد",
    ''=>"",
];
