<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'feature_was_created'=>"feature was created",
    'feature_option_was_created'=>"feature option was created",
    'attribute_option_was_created'=>"attribute option was created",
    'feature_was_updated'=>"feature was updated",
    'feature_not_found'=>"feature not found",
    ''=>"",
];
