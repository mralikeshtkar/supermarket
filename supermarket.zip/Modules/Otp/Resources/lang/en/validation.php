<?php

return [
    'attributes' => [
        "mobile" => "mobile number",
        "code" => "code",
    ],
];
