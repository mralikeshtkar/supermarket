<?php

return [
    'activation_code_sent_successfully' => "Activation code sent successfully",
    'internal_error' => "Internal Error",
    'login_was_successful' => "Login was successful",
    'the_verification_code_is_incorrect' => "The verification code is incorrect",
    'the_request_is_not_valid' => "The request is not valid",
    'otp_not_found'=>"Otp not found",
    'otp_resend_sent'=>"New activation code sent successfully",
];
