<?php

return [
    'attributes' => [
        "mobile" => "شماره موبایل",
        "code" => "کد فعالسازی",
    ],
];
