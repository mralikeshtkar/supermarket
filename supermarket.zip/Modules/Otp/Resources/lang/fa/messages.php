<?php

return [
    'activation_code_sent_successfully' => "کد فعالسازی با موفقیت ارسال شد",
    'internal_error' => "خطا در انجام عملیات",
    'login_was_successful' => "ورود به حساب کاربری با موفقیت انجام شد",
    'the_verification_code_is_incorrect' => "کد تایید اشتباه میباشد",
    'the_request_is_not_valid'=>"درخواست معتبر نمیباشد",
    'otp_not_found'=>"تایید دو مرحله ای یافت نشد",
    'otp_resend_sent'=>"کد فعالسازی جدید با موفقیت ارسال شد",
];
