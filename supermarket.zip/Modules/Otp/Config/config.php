<?php

return [
    'name' => 'Otp',
    'verification_code_digits_length' => 6,
    'expiration_verification_code_time' => 120,
];
