<?php

use Modules\Product\Enums\ProductStatus;

return [
    ProductStatus::class => [
        ProductStatus::Pending => "در حال بررسی",
        ProductStatus::Accepted => "تایید شده",
        ProductStatus::Rejected => "رد شده",
    ],
];
