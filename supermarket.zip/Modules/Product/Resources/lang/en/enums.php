<?php

use Modules\Product\Enums\ProductStatus;

return [
    ProductStatus::class => [
        ProductStatus::Pending => "Pending",
        ProductStatus::Accepted => "Accepted",
        ProductStatus::Rejected => "Rejected",
    ],
    'statuses'=>[
        ProductStatus::class => [
            ProductStatus::Pending => "badge-warning",
            ProductStatus::Accepted => "badge-success",
            ProductStatus::Rejected => "badge-danger",
        ],
    ],
];
