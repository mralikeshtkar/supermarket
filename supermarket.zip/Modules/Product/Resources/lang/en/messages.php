<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'product_was_created'=>"Product was created",
    'product_was_updated'=>"Product was updated",
    'product_was_deleted'=>"Product was deleted",
    'product_not_found'=>"Product not found",
    'gallery_was_deleted'=>"Gallery was deleted",
    'gallery_was_uploaded'=>"Gallery was uploaded",
    'gallery_not_found'=>"Gallery not found",
    'model_was_uploaded'=>"Model was uploaded",
    'model_was_deleted'=>"Model was deleted",
    'product_status_was_updated'=>"Product status was updated",
];
