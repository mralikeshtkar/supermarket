<?php

return [
    'attributes' => [
        'name' => "product name",
        'slug' => "product slug",
        'price' => "product price",
        'image' => "product image",
        'categories_id' => "product categories",
        'tags_id' => "product tags",
    ],
];
