<?php

return [
    'name' => 'Product',
    'minimum_product_price' => 0,
    'collection_gallery' => "gallery",
    'collection_model' => "model",
];
