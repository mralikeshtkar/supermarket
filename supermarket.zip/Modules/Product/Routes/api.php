<?php

use Illuminate\Routing\Router;
use Modules\Product\Http\Controllers\V1\Api\ApiAdminProductController as V1ApiAdminProductController;
use Modules\Product\Http\Controllers\V1\Api\ApiProductController as V1ApiProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('v1')->group(function (Router $router) {
    $router->get('products/{product}/attributes', [V1ApiProductController::class, 'attributes'])
        ->name('product.v1.api-product.attributes.get.api');
    $router->middleware('auth:sanctum')->group(function (Router $router) {
        $router->match(['put', 'patch'], 'products/{product}/change-status', [V1ApiProductController::class, 'changeStatus'])
            ->name('product.v1.api-product.change-status.patch.api');
        $router->group(['prefix' => 'admin'], function (Router $router) {
            $router->get('products', [V1ApiAdminProductController::class, 'index'])
                ->name('product.v1.api-admin-product.index.get.api');
            $router->post('products', [V1ApiAdminProductController::class, 'store'])
                ->name('product.v1.api-admin-product.store.post.api');
            $router->get('products/search-all', [V1ApiAdminProductController::class, 'searchAll'])
                ->name('product.v1.api-admin-product.search-all.get.api');
            $router->get('products/{product}', [V1ApiAdminProductController::class, 'show'])
                ->name('product.v1.api-admin-product.show.get.api');
            $router->delete('products/{product}', [V1ApiAdminProductController::class, 'destroy'])
                ->name('product.v1.api-admin-product.destroy.delete.api');
            $router->get('products/{product}/gallery', [V1ApiAdminProductController::class, 'gallery'])
                ->name('product.v1.api-admin-product.gallery.get.api');
            $router->match(['put', 'patch'], 'products/{product}/change-sort-gallery', [V1ApiAdminProductController::class, 'changeSortGallery'])
                ->name('product.v1.api-admin-product.change-sort-gallery.patch.api');
            $router->post('products/{product}/gallery', [V1ApiAdminProductController::class, 'uploadGallery'])
                ->name('product.v1.api-admin-product.upload-gallery.post.api');
            $router->delete('products/{product}/gallery/{media}', [V1ApiAdminProductController::class, 'destroyGallery'])
                ->name('product.v1.api-admin-product.destroy-gallery.delete.api');
            $router->post('products/{product}/model', [V1ApiAdminProductController::class, 'uploadModel'])
                ->name('product.v1.api-admin-product.upload-model.post.api');
            $router->get('products/{product}/model', [V1ApiAdminProductController::class, 'model'])
                ->name('product.v1.api-admin-product.model.get.api');
            $router->delete('products/{product}/model', [V1ApiAdminProductController::class, 'destroyModel'])
                ->name('product.v1.api-admin-product.destroy-model.delete.api');
            $router->match(['put', 'patch'], 'products/{product}', [V1ApiAdminProductController::class, 'update'])
                ->name('product.v1.api-admin-product.update.patch.api');
            $router->match(['put', 'patch'], 'products/{product}/accept', [V1ApiAdminProductController::class, 'accept'])
                ->name('product.v1.api-admin-product.accept.patch.api');
            $router->match(['put', 'patch'], 'products/{product}/reject', [V1ApiAdminProductController::class, 'reject'])
                ->name('product.v1.api-admin-product.reject.patch.api');
        });
    });
});
