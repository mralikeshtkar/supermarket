<?php

namespace Modules\Product\Http\Controllers\V1\Api;

use BenSampo\Enum\Rules\EnumKey;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Modules\Brand\Entities\Brand;
use Modules\Category\Rules\CategoryRule;
use Modules\Core\Responses\Api\ApiResponse;
use Modules\Core\Rules\ProductModelRule;
use Modules\Feature\Entities\Feature;
use Modules\Media\Entities\Media;
use Modules\Product\Entities\Product;
use Modules\Product\Enums\ProductStatus;
use Modules\Tag\Rules\TagRule;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class ApiProductController extends Controller
{

    /**
     * Show  product's attributes.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function attributes(Request $request, $slug)
    {
        try {
            $product = Product::init()->findOrFailWithSlug($slug);
            $features = Feature::init()->productFeatures($product);
            return ApiResponse::message(trans('product::messages.received_information_successfully'))
                ->addData('product', $product)
                ->addData('features', $features)
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::message(trans('product::messages.product_not_found'), Response::HTTP_NOT_FOUND)
                ->addError('message', $e->getMessage())
                ->hasError()
                ->send();
        } catch (Throwable $e) {
            return ApiResponse::message(trans('product::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }
}
