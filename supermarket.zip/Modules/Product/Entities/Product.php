<?php

namespace Modules\Product\Entities;

use Hekmatinasser\Verta\Verta;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Arr;
use LaravelIdea\Helper\Modules\Product\Entities\_IH_Product_C;
use LaravelIdea\Helper\Modules\Product\Entities\_IH_Product_QB;
use Modules\Brand\Entities\Brand;
use Modules\Category\Traits\HasCategory;
use Modules\Comment\Traits\HasComment;
use Modules\Discount\Traits\HasDiscount;
use Modules\Feature\Traits\HasAttribute;
use Modules\Media\Entities\Media;
use Modules\Media\Traits\HasMedia;
use Modules\Product\Database\factories\ProductFactory;
use Modules\Product\Enums\ProductStatus;
use Modules\Rack\Entities\RackRow;
use Modules\Storeroom\Entities\StoreroomEntrance;
use Modules\Tag\Traits\HasTag;
use Modules\User\Traits\HasFavouritable;
use Staudenmeir\EloquentHasManyDeep\HasRelationships;
use Symfony\Component\HttpFoundation\Response;

class Product extends Model
{
    use HasFactory, HasCategory, HasTag, HasMedia, HasComment, HasAttribute, HasRelationships, HasDiscount, HasFavouritable;

    #region Constance

    protected $fillable = [
        'user_id',
        'brand_id',
        'name',
        'slug',
        'price',
        'status',
    ];

    protected $casts = [
        'global_discount' => 'array',
        'status' => 'integer',
    ];

    protected $appends = [
        'translated_status',
        'status_css_class',
        'created_at_fa',
    ];

    #endregion

    #region Methods

    protected static function boot()
    {
        parent::boot();
        static::deleted(function (Product $product) {
            $product->removeAllMedia();
        });
    }

    /**
     * Init models factory;
     *
     * @return ProductFactory
     */
    protected static function newFactory(): ProductFactory
    {
        return ProductFactory::new();
    }

    /**
     * Initialize class.
     *
     * @return Product
     */
    public static function init(): Product
    {
        return new self();
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|LengthAwarePaginator|_IH_Product_C|Product[]
     */
    public function searchAll(Request $request): \Illuminate\Contracts\Pagination\LengthAwarePaginator|_IH_Product_C|array|LengthAwarePaginator
    {
        return self::query()
            ->with('image')
            ->when($request->filled('search'), function (Builder $builder) use ($request) {
                $builder->where('name', 'LIKE', '%' . $request->search . '%')
                    ->orWhere('slug', 'LIKE', '%' . $request->search . '%');
            })
            ->paginate(2)
            ->appends($request->only('search'));
    }

    public function getProductWhereDontHaveRackRowId(Request $request, $rack_row_id)
    {
        return self::query()
            ->with('image')
            ->whereDoesntHave('rack_rows', function (Builder $builder) use ($rack_row_id) {
                $builder->where('id', $rack_row_id);
            })->when($request->filled('search'), function (Builder $builder) use ($request) {
                $builder->where(function (Builder $builder) use ($request) {
                    $builder->where('name', 'LIKE', '%' . $request->search . '%')
                        ->orWhere('slug', 'LIKE', '%' . $request->search . '%');
                });
            })->accepted()
            ->paginate()
            ->appends($request->only('search'));
    }

    /**
     * @return mixed
     */
    public function getMaximumPrice(): mixed
    {
        return self::query()->max('price');
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|LengthAwarePaginator|_IH_Product_C|Product[]
     */
    public function getAdminIndexPaginate(Request $request): \Illuminate\Contracts\Pagination\LengthAwarePaginator|_IH_Product_C|array|LengthAwarePaginator
    {
        return self::query()
            ->with('image')
            ->withAggregate('brand', 'name')
            ->latest()
            ->paginate(5);
    }

    /**
     * @param $product
     * @param array $relationships
     * @return Model|Collection|_IH_Product_C|Product|Builder|array|_IH_Product_QB|null
     */
    public function findOrFailById($product, array $relationships = []): Model|Collection|_IH_Product_C|Product|Builder|array|_IH_Product_QB|null
    {
        return self::query()->with($relationships)->findOrFail($product);
    }

    /**
     * @param $product
     * @return Model|Collection|_IH_Product_C|Product|Builder|array|_IH_Product_QB
     */
    public function findOrFailByIdCustomException($product): Model|Collection|_IH_Product_C|Product|Builder|array|_IH_Product_QB
    {
        if ($product = self::query()->find($product))
            return $product;
        throw new ModelNotFoundException(trans('product::messages.product_not_found'), Response::HTTP_NOT_FOUND);
    }

    /**
     * @param $value
     * @return bool
     */
    public function existsStoreroomEntrance($value): bool
    {
        return self::query()
            ->whereHas('storeroom_entrances', function (Builder $builder) use ($value) {
                $builder->where('id', Arr::get($value, 'storeroom_entrance_id'))
                    ->where('product_storeroom_entrance.quantity', '>=', Arr::get($value, 'quantity'));
            })->where('id', Arr::get($value, 'product_id'))
            ->exists();
    }

    /**
     * @param Request $request
     * @return Model|Media
     */
    public function uploadGallery(Request $request): Model|Media
    {
        return $this->setDirectory('products')
            ->setCollection(config('product.collection_gallery'))
            ->addMedia($request->image);
    }

    /**
     * Store a product with request data.
     *
     * @param $request
     * @return Model|Builder
     */
    public function store($request): Model|Builder
    {
        $product = self::query()->create([
            'user_id' => $request->user()->id,
            'brand_id' => $request->brand_id,
            'name' => $request->name,
            'slug' => $request->slug,
            'price' => $request->price,
        ]);
        $product->setDirectory('products')
            ->setCollection(config('product.collection_gallery'))
            ->setPriority(1)
            ->addMedia($request->image);
        $product->categories()->sync($request->get('categories_id', []));
        $product->tags()->sync($request->get('tags_id', []));
        return $product->load('gallery');
    }

    /**
     * @param $model
     * @return Model|Media
     */
    public function uploadModel($model): Model|Media
    {
        $this->model?->delete();
        return $this->setDirectory('models')
            ->setCollection(config('product.collection_model'))
            ->addMedia($model);
    }

    /**
     * Delete a product.
     *
     * @return bool|null
     */
    public function destroyProduct(): ?bool
    {
        return $this->delete();
    }

    /**
     * @return bool|null
     */
    public function deleteModel(): ?bool
    {
        return $this->model->delete();
    }

    /**
     * Update a product with valid request data.
     *
     * @param Model|Builder $product
     * @param Request $request
     * @return Model
     */
    public function updateProduct(Model|Builder $product, Request $request): Model
    {
        $product->update([
            'brand_id' => $request->brand_id,
            'name' => $request->name,
            'slug' => $request->slug,
            'price' => $request->price,
        ]);
        $product->when($request->hasFile('image'), function () use ($request, $product) {
            $product->setDirectory('products')
                ->setCollection(config('product.collection_gallery'))
                ->addMedia($request->image);
        });
        $product->when($request->hasFile('model'), function () use ($product, $request) {
            $product->model()->delete();
            $product->setDirectory('models')
                ->setCollection(config('product.collection_model'))
                ->addMedia($request->model);
        });
        $product->categories()->sync($request->get('categories_id', []));
        $product->tags()->sync($request->get('tags_id', []));
        return $product->refresh()->load(['gallery', 'model']);
    }

    /**
     * @param mixed $status
     * @return Product
     */
    public function changeStatus(mixed $status): Product
    {
        $this->update(['status' => $status]);
        return $this->refresh();
    }

    public function findOrFailWithEnough($id): Model|Collection|_IH_Product_C|Product|Builder|array|_IH_Product_QB|null
    {
        return self::query()
            ->withAggregate('storeroom_entrances AS storeroom_quantity', 'SUM(quantity)')
            ->findOrFail($id);
    }

    /**
     * @param $user
     * @return Collection|_IH_Product_C|array|\Illuminate\Support\Collection
     */
    public function getCartData($user): Collection|_IH_Product_C|array|\Illuminate\Support\Collection
    {
        $cart = collect($user->cart);
        return self::query()
            ->with(['gallery', 'model'])
            ->whereIn('id', $cart->keys()->toArray())
            ->get()
            ->map(fn($item) => collect($item)
                ->put('quantity', Arr::get($cart->get($item->id), 'quantity', 1))
                ->put('cart_price', Arr::get($cart->get($item->id), 'quantity', 1) * $item->finalPrice)
            );
    }

    #endregion

    #region Relationships

    /**
     * @return MorphMany
     */
    public function gallery(): MorphMany
    {
        return $this->media()
            ->select('id', 'model_id', 'model_type', 'disk', 'files')
            ->orderByAscPriority()
            ->where('collection', config('product.collection_gallery'));
    }

    /**
     * @return MorphOne
     */
    public function image(): MorphOne
    {
        return $this->morphOne(Media::class, 'model')
            ->select('id', 'model_id', 'model_type', 'disk', 'files')
            ->orderByAscPriority()
            ->where('collection', config('product.collection_gallery'));
    }

    /**
     * @return MorphOne
     */
    public function model(): MorphOne
    {
        return $this->morphOne(Media::class, 'model')
            ->select('id', 'model_id', 'model_type', 'disk', 'files')
            ->where('collection', config('product.collection_model'));
    }

    /**
     * @return BelongsToMany
     */
    public function storeroom_entrances(): BelongsToMany
    {
        return $this->belongsToMany(StoreroomEntrance::class);
    }

    /**
     * @return BelongsTo
     */
    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    public function rack_rows()
    {
        return $this->belongsToMany(RackRow::class)->withTimestamps();
    }

    #endregion

    #region Scopes

    /**
     * @param Builder $builder
     * @return void
     */
    public function scopeAccepted(Builder $builder)
    {
        $builder->where('status', ProductStatus::Accepted);
    }

    /**
     * @param Builder $builder
     * @return void
     */
    public function scopeRejected(Builder $builder)
    {
        $builder->where('status', ProductStatus::Rejected);
    }

    /**
     * @param Builder $builder
     * @return void
     */
    public function scopePending(Builder $builder)
    {
        $builder->where('status', ProductStatus::Rejected);
    }

    #endregion

    #region Mutators

    /**
     * @return string
     */
    public function getTranslatedStatusAttribute(): string
    {
        return ProductStatus::getDescription($this->status);
    }

    public function getStatusCssClassAttribute()
    {
        return ProductStatus::fromValue($this->status)->getCssClass();
    }

    /**
     * @return string
     */
    public function getCreatedAtFaAttribute(): string
    {
        return Verta::instance($this->created_at)->formatJalaliDate();
    }

    #endregion

}
