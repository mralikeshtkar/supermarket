<?php

namespace Modules\Storeroom\Http\Controllers\V1\Api;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Modules\Core\Responses\Api\ApiResponse;
use Modules\Storeroom\Entities\Storeroom;
use Modules\Storeroom\Entities\StoreroomEntrance;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class ApiAdminStoreroomEntranceController extends Controller
{
    /**
     * @param Request $request
     * @param $storeroom
     * @return JsonResponse
     */
    public function index(Request $request, $storeroom)
    {
        try {
            $storeroom = Storeroom::init()->findByIdOrFail($storeroom);
            return ApiResponse::message(trans('storeroom::messages.received_information_successfully'))
                ->addData('entrances', $storeroom->getAdminEntrancePaginate($request))
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendError(trans('storeroom::messages.storeroom_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('storeroom::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * @param Request $request
     * @param $storeroom
     * @return JsonResponse
     */
    public function store(Request $request, $storeroom)
    {
        ApiResponse::init($request->all(), [
            'products' => ['required', 'array', 'min:1'],
            'products.*.id' => ['required', 'distinct', 'exists:products,id'],
            'products.*.quantity' => ['required', 'numeric', 'min:1'],
            'products.*.price' => ['required', 'numeric', 'min:1'],
        ], [], [
            'products' => trans('Products'),
            'products.*.id' => trans('Product id'),
            'products.*.quantity' => trans('Product quantity'),
            'products.*.price' => trans('Product price'),
        ])->validate();
        try {
            $storeroom = Storeroom::init()->findByIdOrFail($storeroom);
            StoreroomEntrance::init()->store($storeroom, $request);
            return ApiResponse::message(trans('storeroom::messages.storeroom_entrance_was_created'))->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendError(trans('storeroom::messages.storeroom_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('storeroom::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * @param Request $request
     * @param $entrance
     * @return JsonResponse
     */
    public function products(Request $request, $entrance)
    {
        try {
            $entrance = StoreroomEntrance::init()->findByIdOrFail($entrance);
            return ApiResponse::message(trans('storeroom::messages.received_information_successfully'))
                ->addData('products',$entrance->paginateProducts($request))
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendError(trans('storeroom::messages.storeroom_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('storeroom::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }
}
