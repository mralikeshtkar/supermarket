<?php

return [
    'name' => 'Storeroom'
];
