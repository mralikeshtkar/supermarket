<?php

namespace Modules\Storeroom\Entities;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\Pivot;

class ProductStoreroomOut extends Pivot
{

}
