<?php

namespace Modules\Comment\Http\Controllers\V1\Api;

use App\Http\Controllers\Controller;
use BenSampo\Enum\Rules\EnumKey;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Modules\Brand\Entities\Brand;
use Modules\Comment\Entities\Comment;
use Modules\Comment\Enums\CommentStatus;
use Modules\Core\Responses\Api\ApiResponse;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class ApiAdminCommentController extends Controller
{
    public function changeStatus(Request $request, $comment)
    {
        ApiResponse::authorize($request->user()->can('changeStatus', Comment::class));
        ApiResponse::init($request->all(), [
            'status' => ['required', new EnumKey(CommentStatus::class)],
        ])->validate();
        try {
            $comment = Comment::init()->findByIdOrFail($comment);
            $comment = $comment->updateStatus(CommentStatus::fromKey($request->status));
            return ApiResponse::message(trans('comment::messages.status_comment_changed'))
                ->addData('comment', $comment)
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::message(trans('comment::messages.comment_not_found'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->hasError()
                ->send();
        } catch (Throwable $e) {
            return ApiResponse::message(trans('comment::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->hasError()
                ->send();
        }
    }
}
