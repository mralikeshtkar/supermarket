<?php

return [
    'name' => 'Comment'
];
