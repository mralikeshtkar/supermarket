<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'comment_not_found'=>"comment not found",
    'comment_was_created'=>"comment was created",
    'comment_was_updated'=>"comment was updated",
    'comment_was_deleted'=>"comment was deleted",
];
