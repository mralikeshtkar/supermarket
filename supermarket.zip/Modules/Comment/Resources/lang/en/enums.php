<?php

use Modules\Comment\Enums\CommentStatus;

return [
    CommentStatus::class => [
        CommentStatus::Pending => "Pending",
        CommentStatus::Accepted => "Accepted",
        CommentStatus::Rejected => "Rejected",
    ],
];
