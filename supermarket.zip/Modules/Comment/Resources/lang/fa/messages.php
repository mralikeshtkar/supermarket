<?php

return [
    'received_information_successfully' => "دریافت اطلاعات با موفقیت انجام شد",
    'internal_error'=>"خطا در انجام عملیات",
    'comment_not_found'=>"دیدگاه مورد نظر پیدا نشد",
    'comment_was_created'=>"دیدگاه با موفقیت ایجاد شد",
    'comment_was_updated'=>"دیدگاه با موفقیت بروزرسانی شد",
    'comment_was_deleted'=>"دیدگاه با موفقیت حذف شد",
];
