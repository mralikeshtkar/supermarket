<?php

namespace Modules\Comment\Entities;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use LaravelIdea\Helper\Modules\Comment\Entities\_IH_Comment_C;
use LaravelIdea\Helper\Modules\Comment\Entities\_IH_Comment_QB;
use Modules\Comment\Database\factories\CommentFactory;
use Modules\Comment\Enums\CommentStatus;

class Comment extends Model
{
    use HasFactory;

    #region Constance

    protected $fillable = [
        'user_id',
        'parent_id',
        'commentable_id',
        'commentable_type',
        'title',
        'body',
        'advantage',
        'disadvantage',
        'status',
    ];

    protected $casts = [
        'advantage' => 'array',
        'disadvantage' => 'array',
    ];

    protected $appends=[
        'translated_status',
    ];

    #endregion

    #region Mutators

    /**
     * @return string
     */
    public function getTranslatedStatusAttribute(): string
    {
        return CommentStatus::getDescription($this->status);
    }

    #endregion

    #region Methods

    /**
     * Initialize class.
     *
     * @return Comment
     */
    public static function init(): Comment
    {
        return new self();
    }

    /**
     * Check exists accepted comment in table.
     *
     * @param mixed $id
     * @param string $column
     * @return mixed
     */
    public function existAcceptedComment(mixed $id, string $column = 'id'): mixed
    {
        return self::query()
            ->where($column, $id)
            ->accepted()
            ->exists();
    }

    protected static function newFactory(): CommentFactory
    {
        return CommentFactory::new();
    }

    /**
     * @param $comment
     * @return Model|Collection|array|_IH_Comment_QB|Builder|_IH_Comment_C|Comment|null
     */
    public function findByIdOrFail($comment): Model|Collection|array|_IH_Comment_QB|Builder|_IH_Comment_C|Comment|null
    {
        return self::query()->findOrFail($comment);
    }

    /**
     * @param $status
     * @return Comment
     */
    public function updateStatus($status): Comment
    {
        $this->update(['status' => $status->value]);
        return $this->refresh();
    }

    #endregion

    #region Relationships

    public function commentable()
    {
        return $this->morphTo();
    }

    #endregion

    #region Scopes

    public function scopeAccepted(Builder $builder)
    {
        $builder->where('status', CommentStatus::Accepted);
    }

    #endregion

}
