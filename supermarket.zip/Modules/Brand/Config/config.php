<?php

return [
    'name' => 'Brand',
    'collection_gallery' => 'gallery',
];
