<?php

namespace Modules\Brand\Http\Controllers\V1\Api;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Modules\Brand\Entities\Brand;
use Modules\Brand\Enums\BrandStatus;
use Modules\Core\Responses\Api\ApiResponse;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class ApiBrandController extends Controller
{
    /**
     * Store a brand from call api.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request)
    {
        ApiResponse::authorize($request->user()->can('store', Brand::class));
        $request->merge([
            'slug' => Str::slug($request->slug),
            'name_en' => ucfirst($request->name_en),
        ]);
        ApiResponse::init($request->all(), [
            'name' => ['required', 'string'],
            'name_en' => ['required', 'string'],
            'slug' => ['required', 'string', 'unique:' . Brand::class . ',slug'],
            'image' => ['nullable', 'image'],
        ], [], trans('brand::validation.attributes'))->validate();
        try {
            $brand = Brand::init()->store($request);
            return ApiResponse::message(trans('brand::messages.brand_was_created'))
                ->addData('brand', $brand)
                ->send();
        } catch (Throwable $e) {
            return ApiResponse::message(trans('brand::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * Show a brand.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function show(Request $request, $slug)
    {
        try {
            $brand = Brand::init()->findByColumnOrFail($slug, 'slug', BrandStatus::Accepted);
            return ApiResponse::message(trans('brand::messages.received_information_successfully'))
                ->addData('brand', $brand)
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendMessage(trans('brand::messages.brand_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('brand::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * Update a brand.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function update(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('update', Brand::class));
        $request->merge([
            'slug' => Str::slug($request->slug),
            'name_en' => ucfirst($request->name_en),
        ]);
        ApiResponse::init($request->all(), [
            'name' => ['required', 'string'],
            'name_en' => ['required', 'string'],
            'slug' => ['required', 'string', Rule::unique(Brand::class, 'slug')->ignore($slug, 'slug')],
            'image' => ['nullable', 'image'],
        ], [], trans('brand::validation.attributes'))->validate();
        try {
            $brand = Brand::init()->findByColumnOrFail($slug, 'slug');
            $brand = $brand->updateBrand($request);
            return ApiResponse::message(trans('brand::messages.brand_was_updated'))
                ->addData('brand', $brand)
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendMessage(trans('brand::messages.brand_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('brand::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    /**
     * Destroy a brand.
     *
     * @param Request $request
     * @param $slug
     * @return JsonResponse
     */
    public function destroy(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('destroy', Brand::class));
        try {
            $brand = Brand::init()->findByColumnOrFail($slug, 'slug');
            $brand->destroyBrand();
            return ApiResponse::message(trans('brand::messages.brand_was_deleted'))
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendMessage(trans('brand::messages.brand_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('brand::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->addError('message', $e->getMessage())
                ->send();
        }
    }

    public function accept(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('manage', Brand::class));
        return $this->_changeStatus($request, $slug, BrandStatus::Accepted());
    }

    public function reject(Request $request, $slug)
    {
        ApiResponse::authorize($request->user()->can('manage', Brand::class));
        return $this->_changeStatus($request, $slug, BrandStatus::Rejected());
    }

    /**
     * @param Request $request
     * @param $slug
     * @param mixed $status
     * @return JsonResponse
     */
    private function _changeStatus(Request $request, $slug, mixed $status): JsonResponse
    {
        try {
            $brand = Brand::init()->findByColumnOrFail($slug, 'slug');
            $brand->changeStatus($status->value);
            $brand->status =$status->description;
            return ApiResponse::message(trans('brand::messages.the_status_of_the_brand_has_been_successfully_changed'))
                ->addData('brand',$brand)
                ->send();
        } catch (ModelNotFoundException $e) {
            return ApiResponse::sendError(trans('brand::messages.brand_not_found'), Response::HTTP_NOT_FOUND);
        } catch (Throwable $e) {
            return ApiResponse::message(trans('brand::messages.internal_error'), Response::HTTP_INTERNAL_SERVER_ERROR)
                ->hasError()
                ->addError('message', $e->getMessage())
                ->send();
        }
    }
}
