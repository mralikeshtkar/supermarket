<?php

namespace Modules\Brand\Entities;

use Hekmatinasser\Verta\Verta;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Http\Request;
use Modules\Brand\Database\factories\BrandFactory;
use Modules\Brand\Enums\BrandStatus;
use Modules\Media\Entities\Media;
use Modules\Media\Traits\HasMedia;

class Brand extends Model
{
    use HasFactory, HasMedia;

    #region Constance

    protected $fillable = [
        'name',
        'name_en',
        'slug',
        'status',
    ];

    protected $casts = [
        'image' => 'array',
    ];

    protected $appends = [
        'translated_status',
        'status_css_class',
        'created_at_fa',
    ];

    #endregion

    #region Mutators

    /**
     * @return string
     */
    public function getTranslatedStatusAttribute(): string
    {
        return BrandStatus::getDescription($this->status);
    }

    /**
     * @return string
     */
    public function getStatusCssClassAttribute(): string
    {
        return BrandStatus::fromValue($this->status)->getCssClass();
    }

    /**
     * @return string
     */
    public function getCreatedAtFaAttribute(): string
    {
        return Verta::instance($this->created_at)->formatJalaliDate();
    }

    #endregion

    #region Methods

    protected static function boot()
    {
        parent::boot();
        static::deleting(function ($brand) {
            foreach ($brand->media()->get() as $media) {
                $media->delete();
            }
        });
    }

    /**
     * Init factory class.
     *
     * @return BrandFactory
     */
    protected static function newFactory(): BrandFactory
    {
        return BrandFactory::new();
    }

    /**
     * Initialize class.
     *
     * @return Brand
     */
    public static function init(): Brand
    {
        return new self();
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function onlyAcceptedBrands(Request $request)
    {
        return self::query()
            ->when($request->filled('search'), function (Builder $builder) use ($request) {
                $builder->where('name', 'LIKE', '%' . $request->search . '%')
                    ->orWhere('name_en', 'LIKE', '%' . $request->search . '%');
            })->accepted()
            ->get();
    }

    /**
     * Store a brand with media.
     *
     * @param Request $request
     * @return Builder|Model
     */
    public function store(Request $request): Model|Builder
    {
        /** @var Brand $brand */
        $brand = self::query()->create([
            'name' => $request->name,
            'name_en' => $request->name_en,
            'slug' => $request->slug,
        ]);
        $brand->when($request->hasFile('image'), function () use ($request, $brand) {
            $brand->removeAllMedia()
                ->setCollection(config('brand.collection_gallery'))
                ->setDirectory('brands')
                ->addMedia($request->image);
        });
        return $brand->refresh()->load('image');
    }

    /**
     * Find a brand with param column.
     *
     * @param $id
     * @param $column
     * @param $status
     * @return Model|Builder
     */
    public function findByColumnOrFail($id, $column = 'id', $status = null): Model|Builder
    {
        return self::query()
            ->where($column, $id)
            ->when($status, function (Builder $builder) use ($status) {
                $builder->where('status', $status);
            })->firstOrFail();
    }

    /**
     * Delete a brand from database.
     *
     * @return bool|null
     */
    public function destroyBrand(): ?bool
    {
        return $this->delete();
    }

    /**
     * @param Request $request
     * @return Brand
     */
    public function updateBrand(Request $request): Brand
    {
        $this->update([
            'name' => $request->name,
            'name_en' => $request->name_en,
            'slug' => $request->slug,
        ]);
        $this->when($request->hasFile('image'), function () use ($request) {
            $this->removeAllMedia()
                ->setCollection(config('brand.collection_gallery'))
                ->setDirectory('brands')
                ->addMedia($request->image);
        });
        return $this->refresh()->load('image');
    }

    /**
     * @param mixed $status
     * @return Brand
     */
    public function changeStatus(mixed $status): Brand
    {
        $this->update(['status' => $status]);
        return $this->refresh();
    }

    /**
     * @param Request $request
     * @return LengthAwarePaginator
     */
    public function getAdminIndexPaginate(Request $request): LengthAwarePaginator
    {
        return self::query()
            ->with('image')
            ->when($request->filled('name'), function (Builder $builder) use ($request) {
                $builder->where('name', 'LIKE', "%" . $request->name . "%")
                    ->orWhere('name_en', 'LIKE', "%" . $request->name . "%");
            })->when($request->filled('date') && validateDate($request->date), function (Builder $builder) use ($request) {
                $builder->whereDate('created_at', Verta::parseFormat('Y/m/d', $request->date)->datetime());
            })->latest()
            ->paginate(3)
            ->appends($request->only(['name', 'date']));
    }

    #endregion

    #region Relationships

    public function image(): MorphOne
    {
        return $this->morphOne(Media::class, 'model')
            ->select('id', 'model_id', 'model_type', 'disk', 'files')
            ->where('collection', config('brand.collection_gallery'));
    }

    #endregion

    #region Scopes

    /**
     * @param Builder $builder
     * @return void
     */
    public function scopeAccepted(Builder $builder)
    {
        $builder->where('status', BrandStatus::Accepted);
    }

    #endregion

}
