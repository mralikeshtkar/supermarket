<?php

return [
    'received_information_successfully' => "دریافت اطلاعات با موفقیت انجام شد",
    'internal_error'=>"خطا در انجام عملیات",
    'brand_not_found'=>"برند مورد نظر پیدا نشد",
    'brand_was_created'=>"برند با موفقیت ایجاد شد",
    'brand_was_updated'=>"برند با موفقیت بروزرسانی شد",
    'brand_was_deleted'=>"برند با موفقیت حذف شد",
    'the_status_of_the_brand_has_been_successfully_changed'=>"وضعیت برند با موفقیت تغییر کرد.",
];
