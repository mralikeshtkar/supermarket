<?php

return [
    'attributes' => [
        'name' => "نام برند",
        'slug' => "لینک برند",
        'name_en' => "نام انگلیسی برند",
        'image' => "تصویر برند",
    ],
];
