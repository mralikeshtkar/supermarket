<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'brand_not_found'=>"brand not found",
    'brand_was_created'=>"brand was created",
    'brand_was_updated'=>"brand was updated",
    'brand_was_deleted'=>"brand was deleted",
    'the_status_of_the_brand_has_been_successfully_changed'=>"The status of the brand has been successfully changed",
];
