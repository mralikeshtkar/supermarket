<?php

return [
    'attributes' => [
        'name' => "brand name",
        'slug' => "brand slug",
        'name_en' => "brand name",
        'image' => "brand image",
    ],
];
