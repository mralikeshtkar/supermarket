<?php

return [
    'attributes' => [
        'name_en' => "English name",
        'name_fa' => "Persian name",
        'permissions' => "Permissions",
    ],
];
