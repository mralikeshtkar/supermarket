<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'role_was_created'=>"Role was created",
    'role_was_updated'=>"Role was updated",
    'role_was_deleted'=>"Role was deleted",
    'role_not_found'=>"Role not found",
];
