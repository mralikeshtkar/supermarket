<?php

return [
    'attributes' => [
        'name_en' => "نام انگلیسی",
        'name_fa' => "نام فارسی",
        'permissions' => "دسترسی ها",
    ],
];
