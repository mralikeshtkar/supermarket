<?php

return [
    'received_information_successfully' => "دریافت اطلاعات با موفقیت انجام شد",
    'internal_error'=>"خطا در انجام عملیات",
    'role_was_created'=>"نقش کاربری با موفقیت ایجاد شد",
    'role_was_updated'=>"نقش کاربری با موفقیت بروزرسانی شد",
    'role_was_deleted'=>"نقش کاربری با موفقیت حذف شد",
    'role_not_found'=>"نقش کاربری پیدا نشد",
];
