<?php

return [
    'name' => 'Permission'
];
