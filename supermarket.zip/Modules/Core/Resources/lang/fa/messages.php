<?php

return [
    'access_forbidden' => "عدم دسترسی",
];
