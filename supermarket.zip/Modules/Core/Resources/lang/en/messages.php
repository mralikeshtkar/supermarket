<?php

return [
    'access_forbidden' => "Access Forbidden",
];
