<?php

namespace Modules\Core\Foundation\Api;

use OpenApi\Annotations as OA;

/**
 * @OA\Info(
 *     version="1.0",
 *     title="Example for response examples value"
 * )
 */
class SwaggerBase
{
    /**
     * @OA\Post(
     *     path="/api/v1/test",
     *     summary="Updates a user",
     *     @OA\Response(
     *         response=200,
     *         description="OK"
     *     )
     * )
     */
    public function index()
    {

    }
}
