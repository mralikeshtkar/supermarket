<?php

namespace Modules\Address\Http\Controllers\V1\Api;

use App\Http\Controllers\Controller;

class ApiAdminAddressController extends Controller
{

}
