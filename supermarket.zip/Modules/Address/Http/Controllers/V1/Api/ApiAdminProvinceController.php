<?php

namespace Modules\Address\Http\Controllers\V1\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Modules\Address\Entities\Province;
use Modules\Core\Responses\Api\ApiResponse;

class ApiAdminProvinceController extends Controller
{

}
