<?php

return [
    'received_information_successfully' => "دریافت اطلاعات با موفقیت انجام شد",
    'internal_error'=>"خطا در انجام عملیات",
    'discount_not_found'=>"تخفیف مورد نظر پیدا نشد",
    'discount_was_created'=>"تخفیف با موفقیت ایجاد شد",
    'discount_was_updated'=>"تخفیف با موفقیت بروزرسانی شد",
    'discount_was_deleted'=>"تخفیف با موفقیت حذف شد",
];
