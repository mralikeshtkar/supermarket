<?php

return [
    'received_information_successfully' => "Received information successfully",
    'internal_error'=>"Internal Error",
    'discount_not_found'=>"discount not found",
    'discount_was_created'=>"discount was created",
    'discount_was_updated'=>"discount was updated",
    'discount_was_deleted'=>"discount was deleted",
];
