<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Permission\\Providers\\PermissionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Permission\\Providers\\PermissionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);