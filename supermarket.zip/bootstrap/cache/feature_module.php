<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Feature\\Providers\\FeatureServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Feature\\Providers\\FeatureServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);