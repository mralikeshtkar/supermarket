<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Address\\Providers\\AddressServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Address\\Providers\\AddressServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);