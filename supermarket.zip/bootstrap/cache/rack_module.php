<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Rack\\Providers\\RackServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Rack\\Providers\\RackServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);