<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Storeroom\\Providers\\StoreroomServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Storeroom\\Providers\\StoreroomServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);