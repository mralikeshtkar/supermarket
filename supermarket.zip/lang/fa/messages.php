<?php

return [
    'throttle' => "لطفا قبل تلاش مجدد منتظر بمانید.",
    'please_log_in_to_your_account' => "لطفا وارد حساب کاربری خود شوید",
    'not_found_http_exception' => "آدرس معتبر نمیباشد.",
];
