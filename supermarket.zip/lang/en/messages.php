<?php

return [
    'throttle'=>"Please wait before trying again.",
    'please_log_in_to_your_account'=>"Please log in to your account",
    'not_found_http_exception'=>"Page not found."
];
